class HomesController < ApplicationController

    # トップ画面
    def top
    end


end
